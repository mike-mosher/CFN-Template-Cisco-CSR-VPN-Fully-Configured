from netmiko import ConnectHandler
from botocore.vendored import requests
import boto3
import json
import logging


# Globals
SUCCESS = "SUCCESS"
FAILED = "FAILED"

logger = logging.getLogger()
logger.setLevel(logging.INFO)



# Globals
logging.basicConfig(level=logging.NOTSET)


def handler(event, context):

    responseData = {}
    ResponseStatus = SUCCESS
    logger.info('RequestType: ' + event['RequestType'])

    if event['RequestType'] in ['Create', 'Update']:

        # Assign vars from event object
        ip = event['ResourceProperties']['CGWPrivateIp']
        username = event['ResourceProperties']['CiscoCsrUsername']
        password = event['ResourceProperties']['CiscoCsrPassword']
        device_type = 'cisco_ios'
        verbose = 'true'

        pass_based_auth_connection_data = {
            'device_type': device_type,
            'ip': ip,
            'username': username,
            'password': password,
            'verbose': verbose
        }

        # Setup the connection
        try:

            # Logging in with password-baseed user creds
            ssh = ConnectHandler(**pass_based_auth_connection_data)

        except:
            logger.info(
                'Unable to setup the connection to the host.  Now exiting the script.')
            exit()

        logger.info('show version: ')
        logger.info(ssh.send_command_expect("show version"))

        # Clean up
        ssh.disconnect()

        if event['RequestType'] == 'Create':
            responseData['Message'] = "Resource creation successful!"
        elif if event['RequestType'] == 'Update':
            responseData['Message'] = "Resource update successful!"

    
    elif event['RequestType'] == 'Delete':

        responseData['Message'] = "Resource deletion successful!"

    else:

        logger.info('RequestType: Not of Type Create/Update/Delete')
        ResponseStatus = FAILED
        responseData['Message'] = "Unexpected event received from CloudFormation"

    logger.info('Sending response now')
    sendResponse(event, context, ResponseStatus, responseData)



def sendResponse(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
    responseUrl = event['ResponseURL']

    print(responseUrl)

    responseBody = {}
    responseBody['Status'] = responseStatus
    responseBody['Reason'] = 'See the details in CloudWatch Log Stream: ' + \
        context.log_stream_name
    responseBody['PhysicalResourceId'] = physicalResourceId or context.log_stream_name
    responseBody['StackId'] = event['StackId']
    responseBody['RequestId'] = event['RequestId']
    responseBody['LogicalResourceId'] = event['LogicalResourceId']
    responseBody['NoEcho'] = noEcho
    responseBody['Data'] = responseData

    json_responseBody = json.dumps(responseBody)

    print("Response body:\n" + json_responseBody)

    headers = {
        'content-type': '',
        'content-length': str(len(json_responseBody))
    }

    try:
        response = requests.put(responseUrl,
                                data=json_responseBody,
                                headers=headers)
        print("Status code: " + response.reason)
    except Exception as e:
        print("send(..) failed executing requests.put(..): " + str(e))
