from netmiko import ConnectHandler
from botocore.vendored import requests
import boto3
import json
import logging
import xmltodict
from textwrap import dedent


# Globals
SUCCESS = "SUCCESS"
FAILED = "FAILED"

logger = logging.getLogger()
logger.setLevel(logging.INFO)
logging.basicConfig(level=logging.NOTSET)


def handler(event, context):

    # testing
    logger.info('event:')
    logger.info(event)
    # end testing

    responseData = {}
    ResponseStatus = SUCCESS
    logger.info('RequestType: ' + event['RequestType'])

    if event['RequestType'] in ['Create', 'Update']:

        # Assign vars from event object
        CGWPublicIp = event['ResourceProperties']['CGWPublicIp']
        CGWPrivateIp = event['ResourceProperties']['CGWPrivateIp']
        CiscoCsrUsername = event['ResourceProperties']['CiscoCsrUsername']
        CiscoCsrPassword = event['ResourceProperties']['CiscoCsrPassword']
        OnPremVPCCidrBlock = event['ResourceProperties']['OnPremVPCCidrBlock']
        CloudVPCCidrBlock = event['ResourceProperties']['CloudVPCCidrBlock']
        KeyPair = event['ResourceProperties']['KeyPair']
        StackName = event['ResourceProperties']['StackName']
        Region = event['ResourceProperties']['Region']

        # Configuration specific to netmiko
        # ip = CGWPrivateIp
        ip = CGWPublicIp
        device_type = 'cisco_ios'
        verbose = 'true'

        pass_based_auth_connection_data = {
            'device_type': device_type,
            'ip': ip,
            'username': CiscoCsrUsername,
            'password': CiscoCsrPassword,
            'verbose': verbose
        }

        ###
        # First step:
        # Find the CGW Configuration Details
        ###

        ec2 = boto3.client('ec2', region_name=Region)

        StackVpnConnection = ec2.describe_vpn_connections(
            Filters=[
                {
                    'Name': 'tag:aws:cloudformation:stack-name',
                    'Values': [ StackName ]
                }
            ]
        )

        if not len(StackVpnConnection['VpnConnections']):
            # Could not find the VPN Connection

            ## Do Something
            print('didn\'t find the VPN connection using SDK')

        VpnConfigXml = StackVpnConnection['VpnConnections'][0]['CustomerGatewayConfiguration']

        doc = xmltodict.parse(VpnConfigXml)

        # CGW configuration vars
        CgwConfigVars = {}

        CgwConfigVars['tunnel_1_cgw_tunnel_outside_address'] = doc['vpn_connection']['ipsec_tunnel'][0]['customer_gateway']['tunnel_outside_address']['ip_address']
        CgwConfigVars['tunnel_1_cgw_tunnel_inside_address'] = doc['vpn_connection']['ipsec_tunnel'][0]['customer_gateway']['tunnel_inside_address']['ip_address']
        CgwConfigVars['tunnel_1_cgw_tunnel_inside_netmask'] = doc['vpn_connection']['ipsec_tunnel'][0]['customer_gateway']['tunnel_inside_address']['network_mask']
        CgwConfigVars['tunnel_1_cgw_asn'] = doc['vpn_connection']['ipsec_tunnel'][0]['customer_gateway']['bgp']['asn']
        
        CgwConfigVars['tunnel_1_vgw_tunnel_outside_address'] = doc['vpn_connection']['ipsec_tunnel'][0]['vpn_gateway']['tunnel_outside_address']['ip_address']
        CgwConfigVars['tunnel_1_vgw_tunnel_inside_address'] = doc['vpn_connection']['ipsec_tunnel'][0]['vpn_gateway']['tunnel_inside_address']['ip_address']
        CgwConfigVars['tunnel_1_vgw_asn'] = doc['vpn_connection']['ipsec_tunnel'][0]['vpn_gateway']['bgp']['asn']
        CgwConfigVars['tunnel_1_psk'] = doc['vpn_connection']['ipsec_tunnel'][0]['ike']['pre_shared_key']

        CgwConfigVars['tunnel_2_cgw_tunnel_outside_address'] = doc['vpn_connection']['ipsec_tunnel'][1]['customer_gateway']['tunnel_outside_address']['ip_address']
        CgwConfigVars['tunnel_2_cgw_tunnel_inside_address'] = doc['vpn_connection']['ipsec_tunnel'][1]['customer_gateway']['tunnel_inside_address']['ip_address']
        CgwConfigVars['tunnel_2_cgw_tunnel_inside_netmask'] = doc['vpn_connection']['ipsec_tunnel'][1]['customer_gateway']['tunnel_inside_address']['network_mask']
        CgwConfigVars['tunnel_2_cgw_asn'] = doc['vpn_connection']['ipsec_tunnel'][1]['customer_gateway']['bgp']['asn']
        
        CgwConfigVars['tunnel_2_vgw_tunnel_outside_address'] = doc['vpn_connection']['ipsec_tunnel'][1]['vpn_gateway']['tunnel_outside_address']['ip_address']
        CgwConfigVars['tunnel_2_vgw_tunnel_inside_address'] = doc['vpn_connection']['ipsec_tunnel'][1]['vpn_gateway']['tunnel_inside_address']['ip_address']
        CgwConfigVars['tunnel_2_vgw_asn'] = doc['vpn_connection']['ipsec_tunnel'][1]['vpn_gateway']['bgp']['asn'] 
        CgwConfigVars['tunnel_2_psk'] = doc['vpn_connection']['ipsec_tunnel'][1]['ike']['pre_shared_key']

        CgwConfigVars['OnPremVPCCidrBlock'] = OnPremVPCCidrBlock.split('/')[0]

        # Get a list of config lines for the CGW based on variables defined above
        configSet = buildCgwConfig(**CgwConfigVars)

        logger.info(configSet)
        

        ###
        # Second step:
        # Use Netmiko to configure the Cisco CSR (CGW)
        ###

        # Setup the connection
        try:

            # Logging in with password-baseed user creds
            ssh = ConnectHandler(**pass_based_auth_connection_data)

        except:
            logger.info(
                'Unable to setup the connection to the host.  Now exiting the script.')
            exit()

        ##
        # Time to send all the commands to the router
        ##
        ssh.config_mode()
        ssh.send_config_set(configSet)

        # Clean up
        ssh.disconnect()

        # Set message for response to Custom Resource
        if event['RequestType'] == 'Create':
            responseData['Message'] = "Resource creation successful!"
        elif event['RequestType'] == 'Update':
            responseData['Message'] = "Resource update successful!"

    
    elif event['RequestType'] == 'Delete':

        responseData['Message'] = "Resource deletion successful!"

    else:

        logger.info('RequestType: Not of Type Create/Update/Delete')
        ResponseStatus = FAILED
        responseData['Message'] = "Unexpected event received from CloudFormation"

    logger.info('Sending response now')
    sendResponse(event, context, ResponseStatus, responseData)



def buildCgwConfig(**configItems):

    config = dedent(f"""
                    !
                    ! --------------------------------------------------------------------------------
                    ! IPSec Tunnel #1
                    ! --------------------------------------------------------------------------------
                    !
                    crypto isakmp policy 200
                    encryption aes 128
                    authentication pre-share
                    group 2
                    lifetime 28800
                    hash sha
                    exit
                    !
                    crypto keyring keyring-vpn-0
                        local-address GigabitEthernet1
                    pre-shared-key address { configItems['tunnel_1_vgw_tunnel_outside_address'] } key { configItems['tunnel_1_psk'] }
                    exit
                    !
                    crypto isakmp profile isakmp-vpn-0
                    local-address GigabitEthernet1
                    match identity address { configItems['tunnel_1_vgw_tunnel_outside_address'] }
                    keyring keyring-vpn-0
                    exit
                    !
                    crypto ipsec transform-set ipsec-prop-vpn-0 esp-aes 128 esp-sha-hmac
                    mode tunnel
                    exit
                    !
                    crypto ipsec profile ipsec-vpn-0
                    set pfs group2
                    set security-association lifetime seconds 3600
                    set transform-set ipsec-prop-vpn-0
                    exit
                    ! 
                    crypto ipsec df-bit clear
                    ! 
                    crypto isakmp keepalive 10 10 on-demand
                    !
                    crypto ipsec security-association replay window-size 128
                    !
                    crypto ipsec fragmentation before-encryption
                    ! 
                    interface Tunnel1
                    ip address { configItems['tunnel_1_cgw_tunnel_inside_address'] } { configItems['tunnel_1_cgw_tunnel_inside_netmask'] }
                    ip virtual-reassembly
                    tunnel source GigabitEthernet1
                    tunnel destination { configItems['tunnel_1_vgw_tunnel_outside_address'] }
                    tunnel mode ipsec ipv4
                    tunnel protection ipsec profile ipsec-vpn-0
                    ip tcp adjust-mss 1379
                    no shutdown
                    exit
                    !
                    ! --------------------------------------------------------------------------------
                    ! #4: Border Gateway Protocol (BGP) Configuration
                    !
                    router bgp { configItems['tunnel_1_cgw_asn'] }
                    neighbor { configItems['tunnel_1_vgw_tunnel_inside_address'] } remote-as { configItems['tunnel_1_vgw_asn'] }
                    neighbor { configItems['tunnel_1_vgw_tunnel_inside_address'] } activate
                    neighbor { configItems['tunnel_1_vgw_tunnel_inside_address'] } timers 10 30 30
                    address-family ipv4 unicast
                        neighbor { configItems['tunnel_1_vgw_tunnel_inside_address'] } remote-as { configItems['tunnel_1_vgw_asn'] }
                        neighbor { configItems['tunnel_1_vgw_tunnel_inside_address'] } timers 10 30 30
                        neighbor { configItems['tunnel_1_vgw_tunnel_inside_address'] } default-originate
                        neighbor { configItems['tunnel_1_vgw_tunnel_inside_address'] } activate
                        neighbor { configItems['tunnel_1_vgw_tunnel_inside_address'] } soft-reconfiguration inbound
                        network { configItems['OnPremVPCCidrBlock'] }
                    exit
                    exit
                    !
                    ! --------------------------------------------------------------------------------
                    ! IPSec Tunnel #2
                    ! --------------------------------------------------------------------------------
                    !
                    crypto isakmp policy 201
                    encryption aes 128
                    authentication pre-share
                    group 2
                    lifetime 28800
                    hash sha
                    exit
                    !
                    crypto keyring keyring-vpn-1
                        local-address GigabitEthernet1
                    pre-shared-key address { configItems['tunnel_2_vgw_tunnel_outside_address'] } key { configItems['tunnel_2_psk'] }
                    exit
                    !
                    crypto isakmp profile isakmp-vpn-1
                    local-address GigabitEthernet1
                    match identity address { configItems['tunnel_2_vgw_tunnel_outside_address'] }
                    keyring keyring-vpn-1
                    exit
                    !
                    crypto ipsec transform-set ipsec-prop-vpn-1 esp-aes 128 esp-sha-hmac
                    mode tunnel
                    exit
                    !
                    crypto ipsec profile ipsec-vpn-1
                    set pfs group2
                    set security-association lifetime seconds 3600
                    set transform-set ipsec-prop-vpn-1
                    exit
                    !
                    crypto ipsec df-bit clear
                    !
                    crypto isakmp keepalive 10 10 on-demand
                    !
                    crypto ipsec security-association replay window-size 128
                    !
                    crypto ipsec fragmentation before-encryption
                    !
                    ! --------------------------------------------------------------------------------
                    ! #3: Tunnel Interface Configuration
                    !
                    interface Tunnel2
                    ip address { configItems['tunnel_2_cgw_tunnel_inside_address'] } { configItems['tunnel_2_cgw_tunnel_inside_netmask'] }
                    ip virtual-reassembly
                    tunnel source GigabitEthernet1
                    tunnel destination { configItems['tunnel_2_vgw_tunnel_outside_address'] }
                    tunnel mode ipsec ipv4
                    tunnel protection ipsec profile ipsec-vpn-1
                    ip tcp adjust-mss 1379
                    no shutdown
                    exit
                    !
                    ! --------------------------------------------------------------------------------
                    ! #4: Border Gateway Protocol (BGP) Configuration
                    !
                    router bgp { configItems['tunnel_2_cgw_asn'] }
                    neighbor { configItems['tunnel_2_vgw_tunnel_inside_address'] } remote-as { configItems['tunnel_2_vgw_asn'] }
                    neighbor { configItems['tunnel_2_vgw_tunnel_inside_address'] } activate
                    neighbor { configItems['tunnel_2_vgw_tunnel_inside_address'] } timers 10 30 30
                    address-family ipv4 unicast
                        neighbor { configItems['tunnel_2_vgw_tunnel_inside_address'] } remote-as { configItems['tunnel_2_vgw_asn'] }
                        neighbor { configItems['tunnel_2_vgw_tunnel_inside_address'] } timers 10 30 30
                        neighbor { configItems['tunnel_2_vgw_tunnel_inside_address'] } default-originate
                        neighbor { configItems['tunnel_2_vgw_tunnel_inside_address'] } activate
                        neighbor { configItems['tunnel_2_vgw_tunnel_inside_address'] } soft-reconfiguration inbound
                        network { configItems['OnPremVPCCidrBlock'] }
                    exit
                    exit
                    !
    """)

    return config.split('\n')



def sendResponse(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
    responseUrl = event['ResponseURL']

    print(responseUrl)

    responseBody = {}
    responseBody['Status'] = responseStatus
    responseBody['Reason'] = 'See the details in CloudWatch Log Stream: ' + \
        context.log_stream_name
    responseBody['PhysicalResourceId'] = physicalResourceId or context.log_stream_name
    responseBody['StackId'] = event['StackId']
    responseBody['RequestId'] = event['RequestId']
    responseBody['LogicalResourceId'] = event['LogicalResourceId']
    responseBody['NoEcho'] = noEcho
    responseBody['Data'] = responseData

    json_responseBody = json.dumps(responseBody)

    print("Response body:\n" + json_responseBody)

    headers = {
        'content-type': '',
        'content-length': str(len(json_responseBody))
    }

    try:
        response = requests.put(responseUrl,
                                data=json_responseBody,
                                headers=headers)
        print("Status code: " + response.reason)
    except Exception as e:
        print("send(..) failed executing requests.put(..): " + str(e))
